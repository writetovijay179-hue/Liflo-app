import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface WaitlistEntry {
  id: string;
  email: string;
  referral_code: string;
  referred_by?: string;
  referral_count: number;
  created_at: string;
}

export interface Priority {
  id: string;
  user_id: string;
  title: string;
  completed: boolean;
  completed_at?: string;
  date: string;
  position: number;
  created_at: string;
}

export interface ShareCard {
  id: string;
  user_id: string;
  date: string;
  share_count: number;
  created_at: string;
}
